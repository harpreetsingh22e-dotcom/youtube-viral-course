YT VIRAL VIP COURSE — GitHub Pages
1. Upload index.html to your GitHub Pages repository.
2. Put your PhonePe payment QR image in the same folder and name it qr.png.
3. The flow is: Intro → Payment QR → Access → Course Content.
4. The Telegram invite is already set to the private invite link supplied earlier.
5. The “I've Paid” button is a front-end flow only; for real payment verification, connect a secure backend/payment gateway.
