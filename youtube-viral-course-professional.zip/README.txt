FILES TO UPLOAD TO YOUR GITHUB REPOSITORY
1. index.html
2. course-photo.jpg  ← put your generated course image here
3. youtube_course_199_qr.png  ← put your payment QR here

IMPORTANT:
- Keep the image filenames exactly the same.
- Upload all three files to the same repository folder.
- Commit changes.
- GitHub Pages will update the website.
